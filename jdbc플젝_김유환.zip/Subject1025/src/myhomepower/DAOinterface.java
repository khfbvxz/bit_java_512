package myhomepower;

public interface DAOinterface {

	public abstract void appAllShow();
	public abstract void appInsert();
	public abstract void appDelete() ;
	public abstract void appUpdate();
	public abstract int appCountAll() ;
	public abstract void hoSearch();
	public abstract void powerTotal();
}
